function Yayasan({y1, y2, y3, y4, y5, y6, y7}){
    return(
        <div>
            <h1>Yayasan Terpercaya</h1>
            <ol>
                <li>{y1}</li>
                <li>{y2}</li>
                <li>{y3}</li>
                <li>{y4}</li>
                <li>{y5}</li>
                <li>{y6}</li>
                <li>{y7}</li>
            </ol>
        </div>
    )
}

export default Yayasan