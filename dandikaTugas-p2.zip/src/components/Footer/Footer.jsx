function Footer({nama}) {
  return (
    <div>
      <footer>
        <h3>Copyright &copy;2026 Developed by {nama} </h3>
        <span>Privacy Policy - Terms</span>
      </footer>
    </div>
  );
}

export default Footer