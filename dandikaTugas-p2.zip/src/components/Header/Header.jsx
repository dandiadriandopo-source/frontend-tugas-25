function Header({nama}){
    return(
        <div>
            <h1>{nama}</h1>
            <p>Donasi untuk Sesama Lebih Mudah di {nama}</p>
        </div>
    )
}

export default Header